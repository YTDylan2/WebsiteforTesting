<? include "../../header.php"; ?>
<div class="col s12 m9 l8">
<div class="container" style="width:100%;">
<script>
		document.title = "Friend Requests | BloxCreate";
	</script>
<div class="content-box">
<div class="header-text" style="padding-bottom:15px;">Pending Friend Requests</div><div style="font-size:14px;">You have no pending friend requests at this time.</div></div>
</div>
</div>
<? include "../../footer.php"; ?>