<? include "../header.php"; ?>
<div class="col s12 m9 l8">
<div class="container" style="width:100%;">
<script>document.title = "Upgrade | BLOXCreate";</script>
<div class="row">
<div class="col s12 m12 l3">
<div style="padding:10px 25px;border-top-left-radius:5px;border-top-right-radius:5px;color:white;text-align:center;font-size:18px;" class="brown darken-2">
Bronze
</div>
<div style="padding:15px 25px;color:white;text-align:center;" class="brown darken-1">
<font style="font-size:26px;">$3.49</font><font style="font-size:12px;">/Month</font>
</div>
<div style="padding:15px 25px;background:white;">
<div style="padding:3px 10px;color:#444444;font-size:14px;">
<b>10</b> Daily Cash
</div>
<div style="padding:3px 10px;color:#444444;font-size:14px;">
Join up to <b>15</b> Groups
</div>
<div style="padding:3px 10px;color:#444444;font-size:14px;">
<b>NO</b> Paid Ads
</div>
<div style="padding:3px 10px;color:#444444;font-size:14px;">
<b>1</b> Special Item
</div>
<div style="height:15px;"></div>
<div style="padding:3px 10px;">
<a href="#" class="waves-effect waves-light btn brown darken-1" style="display:block;">Buy Now</a>
</div>
</div>
<div style="height:25px;"></div>
</div>
<div class="col s12 m12 l3">
<div style="padding:10px 25px;border-top-left-radius:5px;border-top-right-radius:5px;color:white;text-align:center;font-size:18px;" class="grey darken-1">
Silver
</div>
<div style="padding:15px 25px;color:white;text-align:center;" class="grey">
<font style="font-size:26px;">$6.49</font><font style="font-size:12px;">/Month</font>
</div>
<div style="padding:15px 25px;background:white;">
<div style="padding:3px 10px;color:#444444;font-size:14px;">
<b>30</b> Daily Cash
</div>
<div style="padding:3px 10px;color:#444444;font-size:14px;">
Join up to <b>25</b> Groups
</div>
<div style="padding:3px 10px;color:#444444;font-size:14px;">
<b>NO</b> Paid Ads
</div>
<div style="padding:3px 10px;color:#444444;font-size:14px;">
<b>2</b> Special Items
</div>
<div style="height:15px;"></div>
<div style="padding:3px 10px;">
<a href="#" class="waves-effect waves-light btn grey" style="display:block;">Buy Now</a>
</div>
</div>
<div style="height:25px;"></div>
</div>
<div class="col s12 m12 l3">
<div style="padding:10px 25px;border-top-left-radius:5px;border-top-right-radius:5px;color:white;text-align:center;font-size:18px;" class="yellow darken-3">
Gold
</div>
<div style="padding:15px 25px;color:white;text-align:center;" class="yellow darken-2">
<font style="font-size:26px;">$11.49</font><font style="font-size:12px;">/Month</font>
</div>
<div style="padding:15px 25px;background:white;">
<div style="padding:3px 10px;color:#444444;font-size:14px;">
<b>70</b> Daily Cash
</div>
<div style="padding:3px 10px;color:#444444;font-size:14px;">
Join up to <b>50</b> Groups
</div>
<div style="padding:3px 10px;color:#444444;font-size:14px;">
<b>NO</b> Paid Ads
</div>
<div style="padding:3px 10px;color:#444444;font-size:14px;">
<b>3</b> Special Items
</div>
<div style="height:15px;"></div>
<div style="padding:3px 10px;">
<a href="#" class="waves-effect waves-light btn yellow darken-2" style="display:block;">Buy Now</a>
</div>
</div>
<div style="height:25px;"></div>
</div>
<div class="col s12 m12 l3">
<div style="padding:10px 25px;border-top-left-radius:5px;border-top-right-radius:5px;color:white;text-align:center;font-size:18px;" class="grey darken-3">
Platinum
</div>
<div style="padding:15px 25px;color:white;text-align:center;" class="grey darken-2">
<font style="font-size:26px;">$18.95</font><font style="font-size:12px;">/Month</font>
</div>
<div style="padding:15px 25px;background:white;">
<div style="padding:3px 10px;color:#444444;font-size:14px;">
<b>130</b> Daily Cash
</div>
<div style="padding:3px 10px;color:#444444;font-size:14px;">
Join up to <b>100</b> Groups
</div>
<div style="padding:3px 10px;color:#444444;font-size:14px;">
<b>NO</b> Paid Ads
</div>
<div style="padding:3px 10px;color:#444444;font-size:14px;">
<b>3</b> Special Items
</div>
<div style="height:15px;"></div>
<div style="padding:3px 10px;">
<a href="#" class="waves-effect waves-light btn grey darken-2" style="display:block;">Buy Now</a>
</div>
</div>
<div style="height:25px;"></div>
</div>
</div>
<div class="row">
<div class="col s12 m6 l6">
<div style="float:right;">
<img src="../Market/Storage/Creator.png" height="250" style="display:block;">
</div>
</div>
<div class="col s12 m6 l6">
<div style="padding-top:65px;">
<div style="font-size:24px;">Looking for Cash?</div>
<div style="font-size:14px;">With Cash, you can buy shiny items and more!</div>
<div style="height:10px;"></div>
<a href="#" class="waves-effect waves-light btn green">Check It Out</a>
</div>
</div>
</div>
</div>
</div>
<? include "../footer.php"; ?>