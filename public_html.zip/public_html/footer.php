		</div>
		<div class="site-footer center-align">
<div style="padding-top:28px;color:white;">
<div style="clear:none;padding:0 15px;display:inline-block;"><a href="/Notes/Terms" style="color:#757575;">TERMS</a></div>
<div style="clear:none;padding:0 15px;display:inline-block;"><a href="/Notes/Privacy" style="color:#757575;">PRIVACY</a></div>
<div style="clear:none;padding:0 15px;display:inline-block;"><a href="#" style="color:#757575;">SUPPORT</a></div>
<div style="clear:none;padding:0 15px;display:inline-block;"><a href="#" style="color:#757575;">ABOUT</a></div>
<div style="clear:none;padding:0 15px;display:inline-block;"><a href="#" style="color:#757575;">JOBS</a></div>
<div style="clear:none;padding:0 15px;display:inline-block;"><a href="#" style="color:#757575;">TEAM</a></div>
<div style="clear:none;padding:0 15px;display:inline-block;"><a href="#" style="color:#757575;">CONTACT</a></div>
<div style="padding-top:15px;padding-bottom:15px;color:#999999;font-size:14px;">© 2017 BloxCreate, Inc.</div>
<div style="clear:none;padding:0 2px;display:inline-block;"><a href="#" target="_blank"><img src="https://storage.googleapis.com/bloxcity-file-storage/assets/images/facebook.png" style="height:25px;"></a></div>
<div style="clear:none;padding:0 2px;display:inline-block;"><a href="#" target="_blank"><img src="https://storage.googleapis.com/bloxcity-file-storage/assets/images/twitter.png" style="height:25px;"></a></div>
</div>
</div>