<html lang="en"><head>
<title>BLOX Create</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="text/javascript" async="" src="https://d31qbv1cthcecs.cloudfront.net/atrk.js"></script><script src="https://storage.googleapis.com/bloxcity-file-storage/assets/js/bundle.js"></script>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Asap:400,700">
<link rel="stylesheet" href="https://storage.googleapis.com/bloxcity-file-storage/assets/css/bc-bundle.css">
<link rel="stylesheet" href="https://www.bloxcity.com/RawSheet.css">
 
<script type="text/javascript">
				_atrk_opts = { atrk_acct:"xrfin1aMp410mh", domain:"bloxcity.com",dynamic: true};
				(function() { var as = document.createElement("script"); as.type = "text/javascript"; as.async = true; as.src = "https://d31qbv1cthcecs.cloudfront.net/atrk.js"; var s = document.getElementsByTagName("script")[0];s.parentNode.insertBefore(as, s); })();
				</script>
<noscript>&lt;img src="https://d5nxst8fruw4z.cloudfront.net/atrk.gif?account=xrfin1aMp410mh" style="display:none" height="1" width="1" alt=""/&gt;</noscript>
 
<style>body{background-color:#efefef!important;color:#404040!important;margin:0;padding:0;}</style></head>

<body><div class="entire-page-wrapper">
<div style="padding-top:100px;"></div>
<div class="container">
<div class="row">
<div class="col s12 m12 l5">
<img src="http://i.imgur.com/ZCtjacS.png" class="responsive-img">
</div>
<div class="col s12 m12 l7">
<div style="border-bottom:1px solid #ccc;">
<center><h1 style="padding-bottom:0;margin-bottom:0;">Error Loading</h1>
</div>
<div style="height:25px;"></div>
<center><font style="font-size:17px;font-weight:500;">
Unfortunately, the page you requested could not be found. If you continue to encounter this error or feel it is an error, please contact support@bloxcreate.site
</font></center>
<div style="height:25px;"></div>
<a href="#" style="display:inline-block;background:#2196F3;color:white;padding:5px 10px;font-size:14px;font-weight:500;border:0;border-radius:2px;border-bottom:1px solid #207FC9;outline:none;" class="edit-hover" onclick="goBack()">Previous Page</a>
&nbsp;&nbsp;&nbsp;<a href="/" style="display:inline-block;background:#2196F3;color:white;padding:5px 10px;font-size:14px;font-weight:500;border:0;border-radius:2px;border-bottom:1px solid #207FC9;outline:none;" class="edit-hover">Back to the Building Site!</a>
</div>
</div>
</div>
</div>
<script>
			function goBack() {
				window.history.back();
			}
			</script>

<div class="hiddendiv common"></div></body></html>